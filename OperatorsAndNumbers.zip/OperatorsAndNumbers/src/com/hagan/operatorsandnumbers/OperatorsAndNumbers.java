/**
 * @author Shane Hagan
 * Date: 11/18/2022
 * Project: Operators and Numbers practice assignment
 */

/**
 * First Bullet Point to write integers in binary notation
 *   0      0     0     0   |  0    0    0   0  |  0   0   0   0  | 0   0   0   0
 * 32768  16384  8192  4096 | 2048 1024 512 256 | 128  64  32  16 | 8   4   2   1
 * 1 = 0000 0000 0000 0001
 * 8 = 0000 0000 0000 1000
 * 33 = 0000 0000 0010 0001
 * 78 = 0000 0000 0100 1110
 * 787 = 0000 0011 0001 0011
 * 33,987 = 1000 0100 1100 0011
 */

/**
 * Second Bullet Point to write binary in integer notation
 *   0      0     0     0   |  0    0    0   0  |  0   0   0   0  | 0   0   0   0
 * 32768  16384  8192  4096 | 2048 1024 512 256 | 128  64  32  16 | 8   4   2   1
 * 0010 = 2
 * 1001 = 8 + 1 = 9
 * 0011 0100 = 32 + 16 + 4 = 52
 * 0111 0010 = 64 + 32 + 16 + 2 = 114
 * 0010 0001 1111 = 512 + 16 + 8 + 4 + 2 + 1 = 543
 * 0010 1100 0110 0111 = 8192 + 2048 + 1024 + 64 + 32 + 4 + 2 + 1 = 11,367
 */

package com.hagan.operatorsandnumbers;

public class OperatorsAndNumbers {

	public static void main(String[] args) {
		shiftNumbersBy1();
		shiftNumbersBy2();
		calculateBitwise();
		incrementInteger();
		incrementMultipleTimes();
		calculatePrefixAndPostfix();
	}
	
	public static void shiftNumbersBy1() {
		System.out.println("Below will demonstrate the left shift by 1\n");
		
		int x = 2;
		System.out.println("The decimal version of x before any changes is: " + x);
		System.out.println("The binary version of " + x + " is: " + Integer.toBinaryString(x));
		
		/**
		 * After the left shift by 1, it should be:
		 * 0010 --> 0100, which is 4
		 */
		x = x << 1;
		System.out.println("The decimal version of x after the left shift is: " + x);
		System.out.println("The binary version of x after the left shift is: " + Integer.toBinaryString(x) + '\n');
		
		int y = 9;
		System.out.println("The decimal version of y before any changes is: " + y);
		System.out.println("The binary version of " + y + " is: " + Integer.toBinaryString(y));
		
		y = y << 1;
		System.out.println("The decimal version of y after the left shift is: " + y);
		System.out.println("The binary version of y after the left shift is: " + Integer.toBinaryString(y) + '\n');
		
		int z = 17;
		System.out.println("The decimal version of z before any changes is: " + z);
		System.out.println("The binary version of " + z + " is: " + Integer.toBinaryString(z));
		
		z = z << 1;
		System.out.println("The decimal version of z after the left shift is: " + z);
		System.out.println("The binary version of z after the left shift is: " + Integer.toBinaryString(z) + '\n');
		
		int q = 88;
		System.out.println("The decimal version of q before any changes is: " + q);
		System.out.println("The binary version of " + q + " is: " + Integer.toBinaryString(q));
		
		q = q << 1;
		System.out.println("The decimal version of q after the left shift is: " + q);
		System.out.println("The binary version of q after the left shift is: " + Integer.toBinaryString(q) + '\n');
		
		System.out.println("-------------------------------------------------------------------------------------\n");
		
	}
	
	public static void shiftNumbersBy2() {
		System.out.println("Below will demonstrate the right shift by 2\n");
		
		int x = 150;
		System.out.println("The decimal version of x before any changes is: " + x);
		System.out.println("The binary version of " + x + " is: " + Integer.toBinaryString(x));
		
		/**
		 * After the right shift by 2, it should be:
		 * 1001 0110 (128 + 16 + 4 + 2 = 150) --> 0010 0101, which is (32 + 4 + 1 = 37)
		 */
		x = x >> 2;
		System.out.println("The decimal version of x after the right shift is: " + x);
		System.out.println("The binary version of x after the right shift is: " + Integer.toBinaryString(x) + '\n');
		
		int y = 225;
		System.out.println("The decimal version of y before any changes is: " + y);
		System.out.println("The binary version of " + y + " is: " + Integer.toBinaryString(y));
		
		y = y >> 2;
		System.out.println("The decimal version of y after the right shift is: " + y);
		System.out.println("The binary version of y after the right shift is: " + Integer.toBinaryString(y) + '\n');
		
		int z = 1555;
		System.out.println("The decimal version of z before any changes is: " + z);
		System.out.println("The binary version of " + z + " is: " + Integer.toBinaryString(z));
		
		z = z >> 2;
		System.out.println("The decimal version of z after the right shift is: " + z);
		System.out.println("The binary version of z after the right shift is: " + Integer.toBinaryString(z) + '\n');
		
		int q = 32456;
		System.out.println("The decimal version of q before any changes is: " + q);
		System.out.println("The binary version of " + q + " is: " + Integer.toBinaryString(q));
		
		q = q >> 2;
		System.out.println("The decimal version of q after the right shift is: " + q);
		System.out.println("The binary version of q after the right shift is: " + Integer.toBinaryString(q) + '\n');
		
		System.out.println("-------------------------------------------------------------------------------------\n");
		
	}
	
	public static void calculateBitwise() {
		System.out.println("Below will demonstrate the bitwise & and | operators\n");
		
		int x = 7, y = 17, z;
		
		/**
		 * The & operator between x and y should be
		 * x = 0000 0111
		 * y = 0001 0001
		 * z = 0000 0001 or 1 as decimal
		 */
		z = x&y;
		System.out.println("The decimal bitwise & operator between " + x + " and " + y + " is " + z);
		System.out.println("The binary bitwise & operator between " + x + " and " + y + " is " + Integer.toBinaryString(z));
		
		/**
		 * The | operator between x and y should be
		 * x = 0000 0111
		 * y = 0001 0001
		 * z = 0001 0111 or 23 as decimal
		 */
		z = x|y;
		System.out.println("The decimal bitwise | operator between " + x + " and " + y + " is " + z);
		System.out.println("The binary bitwise | operator between " + x + " and " + y + " is " + Integer.toBinaryString(z));
		
		System.out.println("-------------------------------------------------------------------------------------\n");
		
	}
	
	public static void incrementInteger() {
		System.out.println("Below will demonstrate the incrementing a value by 1\n");
		
		int x = 5;
		
		System.out.println("The value before incrementing by 1 is: " + x);
		System.out.println("The value after incrementing by 1 is: " + ++x);
		
		System.out.println("-------------------------------------------------------------------------------------\n");
		
	}
	
	/**
	 * Different ways to increment by 1 include: 
	 * Prefix ++ 
	 * Postfix ++ 
	 * Adding 1 to variable and setting it equal to the variable
	 */
	public static void incrementMultipleTimes() {
		System.out.println("Below will demonstrate the incrementing values by 1 multiple times\n");
		int x = 5, y = 10, z = 15;
		
		for (int i = 0; i < 4; i++) {
			System.out.println("x after " + i + " increments is " + x);
			x++;
			
			System.out.println("y after " + i + " increments is " + y);
			++y;
			
			System.out.println("z after " + i + " increments is " + z);
			z = z + 1;
		}
		
		System.out.println("-------------------------------------------------------------------------------------\n");
	}
	
	public static void calculatePrefixAndPostfix() {
		System.out.println("Below will demonstrate the different between adding with postfix ++ and prefix ++\n");
		
		int x = 5, y = 8, sum;
		
		sum = ++x + y;
		System.out.println("The value of sum after doing sum = ++x + y is: " + sum);
		
		sum = x++ + y;
		System.out.println("The value of sum after doing sum = x++ + y is: " + sum);
		
	}

}
